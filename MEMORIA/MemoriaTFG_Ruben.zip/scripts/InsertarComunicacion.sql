INSERT INTO "COMMUNICATION" ("Name", "Type") 
VALUES ('Phone', 'Synchronous');