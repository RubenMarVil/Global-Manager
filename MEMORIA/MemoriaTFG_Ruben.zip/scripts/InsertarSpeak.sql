INSERT INTO "Speak" ("Country", "Language", "Official") 
VALUES ('Argentina', 'English', '0');
INSERT INTO "Speak" ("Country", "Language", "Official") 
VALUES ('Argentina', 'French', '0');
INSERT INTO "Speak" ("Country", "Language", "Official") 
VALUES ('Argentina', 'German', '0');
INSERT INTO "Speak" ("Country", "Language", "Official") 
VALUES ('Argentina', 'Italian', '0');
INSERT INTO "Speak" ("Country", "Language", "Official") 
VALUES ('Argentina', 'Spanish', '1');
INSERT INTO "Speak" ("Country", "Language", "Official") 
VALUES ('Australia', 'English', '1');